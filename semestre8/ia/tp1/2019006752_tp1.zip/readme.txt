Para compilar o programa, no terminal, digite "make pathfinder".
Para executar basta executar conforme a instrução da especificação.

A única biblioteca utilizada é a padrão do C++.

O run.sh é um código bash utilizado para as comparações de tempo e distância de cada algoritmo.
