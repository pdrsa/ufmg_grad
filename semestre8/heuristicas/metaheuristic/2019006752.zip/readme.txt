Para compilar o programa, em um terminal, digite o comando "make tsp".
Para execução de um arquivo $i, digite "./tsp < $i".
Alternativamente, para a execução de todos os casos de teste, digite "sh runAll.sh".