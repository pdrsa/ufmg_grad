max(X,Y,Z) :- (X =< Y, Z = Y) ; (X > Y, Z = X).
