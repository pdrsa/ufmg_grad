ordered([_]).
ordered([X|T]) :- T = [Y|_], X =< Y, ordered(T).
