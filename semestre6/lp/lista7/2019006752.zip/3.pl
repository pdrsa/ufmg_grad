firstPair(X) :- X = [HeadA|TailA], TailA = [HeadB|_], HeadA=HeadB.
