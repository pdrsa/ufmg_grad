third(X,Y) :- Y = [_|TailA], TailA = [_|TailB], TailB = [X|_].
